
#!/bin/bash
# XCS Cyber Investigator Bash Toolkit - xcs_multitool.sh

echo "===== XCS Cyber Investigator Toolkit ====="

while true; do
  echo -e "\nSelect an option:"
  echo "1. WHOIS and IP Info of Website"
  echo "2. Check if Website is Suspicious or Malicious"
  echo "3. Extract Data from QR Code Image"
  echo "4. Username Mapper"
  echo "5. Exit"
  read -p "Enter choice: " choice

  case $choice in
    1)
      read -p "Enter Website URL (e.g. example.com): " domain
      echo -e "\n--- WHOIS Info ---"
      whois "$domain" || echo "whois not installed"
      echo -e "\n--- Real IP and Server Info ---"
      dig +short "$domain"
      dig +short "$domain" | xargs -I{} curl -s -I http://{} | grep "Server:"
      ;;
    2)
      read -p "Enter Website URL (with https://): " url
      echo -e "\n--- VirusTotal (using curl) ---"
      curl -s --request GET --url "https://www.virustotal.com/gui/domain/${url}" || echo "VirusTotal might need API or browser check."
      ;;
    3)
      read -p "Enter path to QR Code image: " qrfile
      if [[ -f "$qrfile" ]]; then
        echo "--- Decoding QR Code ---"
        zbarimg "$qrfile" || echo "Install zbarimg using: sudo apt install zbar-tools"
      else
        echo "File not found."
      fi
      ;;
    4)
      read -p "Enter username to check: " uname
      echo "--- Searching username on common platforms ---"
      for site in facebook.com twitter.com instagram.com github.com reddit.com; do
        echo -n "$site: "
        curl -s -o /dev/null -w "%{http_code}\n" "https://$site/$uname"
      done
      ;;
    5)
      echo "Exiting..."
      break
      ;;
    *)
      echo "Invalid option."
      ;;
  esac
done
